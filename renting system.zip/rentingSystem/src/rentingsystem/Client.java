/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rentingsystem;

import java.util.ArrayList;

/**
 *
 * @author user
 */
public class Client extends AuthorizedUser {
 
   String Email;
    ArrayList <Creditcard> creditcard;
 

   
 private Feedback i;
 private Appointmentinterface a;

 public Client(){
   super();
   }

    public Client(Feedback i, Appointmentinterface a) {
        this.i = i;
        this.a = a;
    }
   

   public Client(ArrayList<Creditcard> creditcard, String Email, int ID, String status, String password, String username, String name, String phone_Number, String address) {
        super(ID, status, password, username, name, phone_Number, address);
        
        this.Email = Email;
       
        this.creditcard=creditcard;
    }
 

  

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public ArrayList<Creditcard> getCreditcard() {
        return creditcard;
    }

    public void setCreditcard(ArrayList<Creditcard> creditcard) {
        this.creditcard = creditcard;
    }

  
    public Feedback getI() {
        return i;
    }

    public void setI(Feedback i) {
        this.i = i;
    }

    public Appointmentinterface getA() {
        return a;
    }

    public void setA(Appointmentinterface a) {
        this.a = a;
    }

    
    
    
    
    public void addFeedback(String comment)
    {
     
        i.addfeedback(comment);
       
    }
    
   
    
    public void viewfeedback(String comment)
    {
        i.viewfeedback(comment);
    }
  public void viewappointment(){
  a.viewappointment();
  }
  
  public void bookappointment(String location ,String date){
  a.bookappointment(location, date);
  
  }
    
}
