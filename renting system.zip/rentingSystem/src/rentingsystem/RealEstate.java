/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rentingsystem;

/**
 *
 * @author salwa saleh
 */
public class RealEstate implements ViewrealestateROI {
    public int id;
    public String city;
    public String type;
    public String street;
    public String country;
    public int totalspace;
    public String postalcode;
    public int noocupants;
    public int price;

    public RealEstate(int id, String city, String type, String street, String country, int totalspace, String postalcode, int noocupants, int price) {
        this.id = id;
        this.city = city;
        this.type = type;
        this.street = street;
        this.country = country;
        this.totalspace = totalspace;
        this.postalcode = postalcode;
        this.noocupants = noocupants;
        this.price = price;
    }
    
    public RealEstate(){}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public int getTotalspace() {
        return totalspace;
    }

    public void setTotalspace(int totalspace) {
        this.totalspace = totalspace;
    }

    public String getPostalcode() {
        return postalcode;
    }

    public void setPostalcode(String postalcode) {
        this.postalcode = postalcode;
    }

    public int getNoocupants() {
        return noocupants;
    }

    public void setNoocupants(int noocupants) {
        this.noocupants = noocupants;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
   
    public void viewrealestate(int id, String city, String type, String street, String country, int totalspace, String postalcode, int noocupants, int price){
    getId();
    getCity();
    getType();
    getStreet();
    getCountry();
    getTotalspace();
    getPostalcode();
    getNoocupants(); 
    }

    @Override
    public void viewrealestate() {
        RealEstate e=new RealEstate();
        e.getCity();
      e.getCountry();
      e.getId();
      e.getNoocupants();
      e.getPice();
      e.getPostalcode();
      e.getStreet();
      e.getTotalspace();
      e.getType();
      
        
        
    }

    @Override
    public int getPice() {
        return price;
    }

}
