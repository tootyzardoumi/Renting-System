/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rentingsystem;



/**
 *
 * @author salwa saleh
 */
public class BookingEngine {
    private RealEstate listOfRealRstate;
    public int ownerID;
    public int clientID;

    public BookingEngine(RealEstate listOfRealRstate, int ownerID, int clientID) {
        this.listOfRealRstate = listOfRealRstate;
        this.ownerID = ownerID;
        this.clientID = clientID;
    }
    public BookingEngine(){

    }
    public RealEstate getListOfRealRstate() {
        return listOfRealRstate;
    }

    public void setListOfRealRstate(RealEstate listOfRealRstate) {
        this.listOfRealRstate = listOfRealRstate;
    }

    public int getOwnerID() {
        return ownerID;
    }

    public void setOwnerID(int ownerID) {
        this.ownerID = ownerID;
    }

    public int getClientID() {
        return clientID;
    }

    public void setClientID(int clientID) {
        this.clientID = clientID;
    }
    
}
