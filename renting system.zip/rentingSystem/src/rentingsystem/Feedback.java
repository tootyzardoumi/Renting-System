/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rentingsystem;


/**
 *
 * @author user
 */
public class Feedback implements Feedback_ROI {
    String comment;
    String name;
   

public Feedback(){
}
    public Feedback(String comment, String name) {
        this.comment = comment;
        this.name = name;
        
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

  
   

  
 
    void addfeedback(String com){
      
        setComment(com);
    
    }
public void viewfeedback(String com){
getComment();
}


    


        
}
