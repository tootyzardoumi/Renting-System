/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rentingsystem;

import java.util.Objects;

/**
 *
 * @author user
 */
public class AuthorizedUser extends User{
    int ID;
    String username;
    String password;
    String status;
public AuthorizedUser(){
   super();
   }
    public AuthorizedUser(int ID,String status,String password,String username,String name, String phone_Number, String address) {
        super(name, phone_Number, address);
        this.ID=ID;
        this.username=username;
        this.password=password;
        this.status=status;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

   
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final AuthorizedUser other = (AuthorizedUser) obj;
        if (this.ID != other.ID) {
            return false;
        }
        if (this.status != other.status) {
            return false;
        }
        if (!Objects.equals(this.username, other.username)) {
            return false;
        }
        if (!Objects.equals(this.password, other.password)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "AuthorizedUser{" + "ID=" + ID + ", username=" + username + ", password=" + password + ", status=" + status + '}';
    }

    
    
    
}
