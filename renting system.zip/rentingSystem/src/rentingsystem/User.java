/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rentingsystem;


import java.util.ArrayList;
import java.util.Objects;

/**
 *
 * @author user
 */
public abstract class User {
   
    String name;
    String phone_Number;
  
    String address;
   ArrayList <RealEstate> realestate =new ArrayList <RealEstate>();
   
   
public User (){
}
    public User(String name, String phone_Number, String address) {
        this.name = name;
        this.phone_Number = phone_Number;
        this.address = address;
    }

   

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone_Number() {
        return phone_Number;
    }

    public void setPhone_Number(String phone_Number) {
        this.phone_Number = phone_Number;
    }


    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public ArrayList<RealEstate> getRealestate() {
        return realestate;
    }

    public void setRealestate(ArrayList<RealEstate> realestate) {
        this.realestate = realestate;
    }
    
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        
        final User other = (User) obj;
        if (!Objects.equals(this.name, other.name)) {
            return false;
        }
         
        if (!Objects.equals(this.phone_Number, other.phone_Number)) {
            return false;
        }
      
        if (!Objects.equals(this.address, other.address)) {
            return false;
        }
        return true;
    }
    
    
@Override
    public String toString() {
        return "Person{" + "name=" + name + " phone=" + phone_Number +  " address=" + address + '}';
    }
    
    
}
