/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rentingsystem;

import java.util.Date;

/**
 *
 * @author hp
 */
public interface Appointmentinterface {
    
    public void bookappointment(String location , String date);
    public void viewappointment();
  
    
}
