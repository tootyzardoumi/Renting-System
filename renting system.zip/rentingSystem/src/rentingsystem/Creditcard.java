package rentingsystem;

/**
 *
 * @author hp
 */
import java.util.Objects;

public class Creditcard {
    int id;
    String cardNumber;
    String expiredDate;
    String cvv;
    String cardHolder;
    Cardtype cardType;

    public Creditcard(int id, String cardNumber, String expiredDate, String cvv,String cardHolder) {
        this.id = id;
        this.cardNumber = cardNumber;
        this.expiredDate = expiredDate;
        this.cvv = cvv;
        this.cardHolder=cardHolder;
   
    }

    public String getCardHolder() {
        return cardHolder;
    }

    public void setCardHolder(String cardHolder) {
        this.cardHolder = cardHolder;
    }

    public Creditcard(Cardtype cardType) {
        this.cardType = cardType;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getExpiredDate() {
        return expiredDate;
    }

    public void setExpiredDate(String expiredDate) {
        this.expiredDate = expiredDate;
    }

    public String getCvv() {
        return cvv;
    }

    public void setCvv(String cvv) {
        this.cvv = cvv;
    }

    public Cardtype getCardType() {
        return cardType;
    }

    public void setCardType(Cardtype cardType) {
        this.cardType = cardType;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Creditcard other = (Creditcard) obj;
        if (this.id != other.id) {
            return false;
        }
        if (!Objects.equals(this.cardNumber, other.cardNumber)) {
            return false;
        }
        if (!Objects.equals(this.expiredDate, other.expiredDate)) {
            return false;
        }
        if (!Objects.equals(this.cvv, other.cvv)) {
            return false;
        }
        if (this.cardType != other.cardType) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "CreditCard{" + "id=" + id + ", cardNumber=" + cardNumber + ", expiredDate=" + expiredDate + ", cvv=" + cvv + ", cardType=" + cardType + '}';
    }
    
    
    
}
