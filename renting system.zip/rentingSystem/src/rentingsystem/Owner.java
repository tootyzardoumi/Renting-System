/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rentingsystem;

import java.util.ArrayList;

/**
 *
 * @author user
 */
public class Owner extends AuthorizedUser {
      private Feedback_ROI i;
   
      
      
        String relestate_document;
        String Email;
        int realestateID;
        
        
    
      
   public Owner(){
   super();
   }

    public Owner(Feedback_ROI i) {
        this.i = i;
    }

  

    public Owner(  String relestate_document, String Email, int realestateID, int ID, String status, String password, String username, String name, String phone_Number, String address) {
        super(ID, status, password, username, name, phone_Number, address);
       
        this.relestate_document = relestate_document;
        this.Email = Email;
        this.realestateID = realestateID;
    }

    public Feedback_ROI getI() {
        return i;
    }

    public void setI(Feedback_ROI i) {
        this.i = i;
    }

    public int getRealestateID() {
        return realestateID;
    }

    public void setRealestateID(int realestateID) {
        this.realestateID = realestateID;
    }

 
    
    public void viewfeedback(String comment)
    {
        i.viewfeedback(comment);
    }
    
    

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }


 

   

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getRelestate_document() {
        return relestate_document;
    }

    public void setRelestate_document(String relestate_document) {
        this.relestate_document = relestate_document;
    }
    
      
      
}
