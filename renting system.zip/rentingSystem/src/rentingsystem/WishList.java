/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rentingsystem;


/**
 *
 * @author salwa saleh
 */
public class WishList {
    private RealEstate re;
    public int id; //wish list id
    public int clientID;
    public int realEstateID;

    public WishList(RealEstate re, int id, int clientID, int realEstateID) {
        this.re = re;
        this.id = id;
        this.clientID = clientID;
        this.realEstateID = realEstateID;
    }
    public WishList(){}

    public RealEstate getRe() {
        return re;
    }

    public void setRe(RealEstate re) {
        this.re = re;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getClientID() {
        return clientID;
    }

    public void setClientID(int clientID) {
        this.clientID = clientID;
    }

    public int getRealEstateID() {
        return realEstateID;
    }

    public void setRealEstateID(int realEstateID) {
        this.realEstateID = realEstateID;
    }
    
    
}