/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rentingsystem;

/**
 *
 * @author hp
 */
import java.util.ArrayList;
import java.util.Date;
public class Appointments implements Appointmentinterface
{
    

    String retype;
    String ownername;
    int id;
    String time;
    String date;
    String location;
public Appointments(String date,String location,String time){
    this.location=location;
    this.date=date;
    this.time=time;
}
    public Appointments(String retype,String ownername,int id,String time, String date, String location) {
        this.time = time;
        this.date = date;
        this.location = location;
        this.id=id;
        this.ownername=ownername;
        this.retype=retype;
    }

    public String getreType() {
        return retype;
    }

    public void seteType(String retype) {
        this.retype = retype;
    }

    public String getOwnername() {
        return ownername;
    }

    public void setOwnername(String ownername) {
        this.ownername = ownername;
    }

  

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
 

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
    
    public void addappointment(String date)
    {
        setDate(date);
    }
    
    
    public void bookappointment(String location , String date)
    {
        setLocation(location);
        setDate(date);
    }
    public void viewappointment(){
        getDate();
    }

  
    
    
}
