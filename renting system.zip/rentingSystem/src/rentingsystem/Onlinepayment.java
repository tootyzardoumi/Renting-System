/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rentingsystem;

import rentingsystem.Payment;

/**
 *
 * @author hp
 */
public class Onlinepayment implements Payment {
    public void pay() {
        //pay online implementation
    }
    
    public void enterDetails() {
        //create object of cedit card and assign it to parent
    }
    
    public void validateCreditCard() {

    }
}
