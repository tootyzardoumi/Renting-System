package rentingsystem;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class DB {
    private final String userName = "root";
    private final String password = "";
    private final String dbName = "rentsys";

    private Connection con;

    public DB() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance();
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + dbName, userName, password);
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException | SQLException e) {
            System.err.println("DATABASE CONNECTION ERROR: " + e.toString());
        }
    }
     public Object login(String userName, String password) {
        try {
            
            
            Statement stmt = con.createStatement();
            ResultSet rs;
           
            //Client
            rs = stmt.executeQuery("SELECT * FROM `client` WHERE  `name` = '" +userName+"' AND password='"+password+"';");
            if (rs.first()) {
                Client Person = new Client();
                Person.setID(rs.getInt("id"));
                Person.setName(rs.getString("name"));
                Person.setEmail(rs.getString("email"));
                Person.setPhone_Number(rs.getString("phone"));
                Person.setAddress(rs.getString("address"));
                Person.setUsername(rs.getString("username"));
                Person.setPassword(rs.getString("password"));
                Person.setStatus(rs.getString("status"));
                return Person;
            }
           
           
            // Owner
            rs = stmt.executeQuery("SELECT * FROM `owner` WHERE  userName = '"+userName+"' AND password='"+password+"';");
            if (rs.first()) {
                Owner Person = new Owner();
                Person.setID(rs.getInt("id"));
                Person.setName(rs.getString("name"));
                Person.setEmail(rs.getString("email"));
                Person.setPhone_Number(rs.getString("phone"));
                Person.setAddress(rs.getString("address"));
                Person.setUsername(rs.getString("userName"));
                Person.setPassword(rs.getString("password"));
                Person.setStatus(rs.getString("status"));
                return Person;
            }
           
        
            //Admin
            rs = stmt.executeQuery("SELECT * FROM `admin` WHERE userName = '"+userName+"' AND password='"+password+"';");
            if (rs.first()) {
                Admin Person = new Admin();
                Person.setName(rs.getString("name"));
                Person.setEmail(rs.getString("email"));
                Person.setPhone_Number(rs.getString("phone"));
                Person.setAddress(rs.getString("address"));
                Person.setUsername(rs.getString("username"));
                Person.setPassword(rs.getString("password"));
                Person.setSalary(rs.getFloat("salary"));
                return Person;
            }
        } catch (SQLException e) {
            System.err.println("DATABASE QUERY ERROR: " + e.toString());
        }
       
       
        return null;
    }
  
    public void addappointment(String time, String date, String location) {
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("INSERT INTO `appointment`(`date`, `location`, `time`) VALUES ('" + time + "','" + date + "','" + location + "')");
            System.out.println("Done");
        } catch (Exception e) {
            System.err.println("DATABASE INSERTION ERROR: " + e.toString());
        }
    }
    public ArrayList<Appointments> viewappointment(){
          ArrayList<Appointments> app = new ArrayList();
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT `date`,`location`,`time` FROM `appointment`");
            while (rs.next()) {
                app.add(new Appointments( rs.getString("date"),rs.getString("location"),rs.getString("time")));
                
            }
        } catch (Exception e) {
            System.err.println("DATABASE QUERY ERROR: " + e.toString());
        }
        return app;
    }
    
    public void addafeedback(String comment ) {
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("INSERT INTO `feedback`(comment )VALUES ('" + comment + "')");
            System.out.println("Done");
        } catch (Exception e) {
            System.err.println("DATABASE INSERTION ERROR: " + e.toString());
        }
    }
     public ArrayList<Feedback> viewfeedback(){
          ArrayList<Feedback> feed = new ArrayList();
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT `name`,`comment` FROM `feedback`");
            while (rs.next()) {
                feed.add(new Feedback( rs.getString("name"),rs.getString("comment")));
                
            }
        } catch (Exception e) {
            System.err.println("DATABASE QUERY ERROR: " + e.toString());
        }
        return feed;
    }
   
   
    public void addowners(Owner o){
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("INSERT INTO `owner` VALUES  ('" + o.getID() + "','" +o.getName() + "','" + o.getPhone_Number() + "','" + o.getEmail() + "','" + o.getPassword() + "','" + o.getStatus() + "','" + o.getUsername() + "','" + o.getAddress() + "','" + o.getRelestate_document() + "','" + o.getRealestateID() + "')");
            System.out.println("Done");
        } catch (Exception e) {
            System.err.println("DATABASE INSERTION ERROR: " + e.toString());
        }
    
    }
    
     public void addClient(   int ID,String name , String phone_Number,String Email,String password ,String status,String username, String address ) {
        try {
            
            Statement stmt = con.createStatement();
            stmt.executeUpdate("INSERT INTO `Client` VALUES  ('" + ID + "','" +name + "','" + phone_Number + "','" + Email + "','" + password + "','" + status + "','" + username + "','" + address + "')");
            System.out.println("Done");
        } catch (Exception e) {
            System.err.println("DATABASE INSERTION ERROR: " + e.toString());
        }
    }
     
     
     public ArrayList <Owner> getOwner(int  ID) {
        ArrayList <Owner> owners = new ArrayList<>();
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT owner.id AS id ,owner.name AS name ,owner.phone AS phone ,owner.realestatetType AS real_estate FROM owner JOIN `real-estate` ON owner.realestateid=`real-estate`.`id` WHERE owner.id= "+ID+";");
            while (rs.next()) {
                Owner o = new Owner();
                
                o.setName(rs.getString("name"));
             
                o.setPhone_Number(rs.getString("phone"));
                o.setRelestate_document(rs.getString("realestateType"));
               
                owners.add(o);
                
                
            }
        } catch (SQLException e) {
            System.err.println("DATABASE QUERY ERROR: " + e.toString());
        }
        return owners;
    }
   
      public ArrayList <Client> getClient(int  ID) {
        ArrayList <Client> client = new ArrayList<>();
        try {
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM client WHERE id= "+ID+";");
            while (rs.next()) {
                Client c = new Client();
                
                c.setName(rs.getString("name"));
                c.setPhone_Number(rs.getString("phone"));
               c.setEmail("email");
               c.setAddress("address");
               c.setPassword("password");
               c.setStatus("true");
               c.setUsername("username");
               
               
                client.add(c);
                
                
            }
        } catch (SQLException e) {
            System.err.println("DATABASE QUERY ERROR: " + e.toString());
        }
        return client;
    }
    public void deleteClient(String name) {
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("delete from client where name = '" + name + "'");
            System.out.println("Client deleted");
        } catch (Exception e) {
            System.err.println("DATABASE DELETION ERROR: " + e.toString());
        }
    }
    
    
     public void deleteOwner(String name) {
        try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("delete from owner where name = '" + name + "'");
            System.out.println("owner deleted");
        } catch (Exception e) {
            System.err.println("DATABASE DELETION ERROR: " + e.toString());
        }
    }
     
     
    
    
    
   
    public void updateowner(String name , String phone_Number,String Email,String password ,String status,String username, String address) {
        try {
            Statement stmt = con.createStatement();
                                                                      
            stmt.executeUpdate("UPDATE `owner` SET `name`="+name+",`phone`="+phone_Number+",`email`="+Email+",`password`="+password+",`status`="+status+",`username`="+username+",`address`="+address+"");
            System.out.println("Done");
        } catch (Exception e) {
            System.err.println("DATABASE INSERTION ERROR: " + e.toString());
        }
    }
    
    
    
    
    
   
    public void updateclient(String name , String phone_Number,String Email,String password ,String status,String username, String address) {
        try {
            Statement stmt = con.createStatement();
                                                                      
            stmt.executeUpdate("UPDATE `client` SET `name`="+name+",`phone`="+phone_Number+",`email`="+Email+",`password`="+password+",`status`="+status+",`username`="+username+",`address`="+address+"");
            System.out.println("Done");
        } catch (Exception e) {
            System.err.println("DATABASE INSERTION ERROR: " + e.toString());
        }
    }
    
  
    
    
    
    
    
    
    
    public RealEstate getREbyID(int id){
 
    try{
 Statement stmt = con.createStatement();
 ResultSet rs = stmt.executeQuery("select * from real-estate where id='" + id + "' ");
 if (rs.first()){
    return new RealEstate(rs.getInt("id"),rs.getString("city"),rs.getString("type"),rs.getString("street"),rs.getString("country"),rs.getInt("totalspace"),rs.getString("postalcode"),rs.getInt("noocupants"),rs.getInt("price"));
 
 }
}
        catch(Exception e){
    System.err.println("DATABASE QUERY ERROR: " + e.toString());
    }
   
    return null;
}

public void deleteRE(int id){
try{
     Statement stmt = con.createStatement();
     stmt.executeUpdate("delete from real-estate where id ='"+id+"'");
     System.out.println("real estate deleted succesfully");
     
}
catch(Exception e){
    System.err.println("DATABASE DELETION ERROR: " + e.toString());
}
}

public void addRE(RealEstate r){
try{
Statement stmt = con.createStatement();
stmt.executeUpdate("insert into real-estate values('" + r.getId()+ "'," + r.getType() + "'," +r.getStreet()+"',"+r.getCountry() +"'," +r.getTotalspace()+"',"+r.getPostalcode()+"',"+r.getNoocupants()+"',"+r.getPrice()+")" );
    System.out.println("Real Estate added succesfully");
}
catch (Exception e) {
            System.err.println("DATABASE DELETION ERROR: " + e.toString());
        }
}

public ArrayList<RealEstate> rentRE(int id){
     ArrayList<RealEstate> booked = new ArrayList();
    try{
 Statement stmt = con.createStatement();
 ResultSet rs = stmt.executeQuery("select * from real-estate where id='" + id + "' ");
 while(rs.next()){
     booked.add(new RealEstate(rs.getInt("id"),rs.getString("city"),rs.getString("type"),rs.getString("street"),rs.getString("country"),rs.getInt("totalspace"),rs.getString("postalcode"),rs.getInt("noocupants"),rs.getInt("price")));
     
 }
 rs = stmt.executeQuery("delete * from real-estate where id='" + id + "' ");
    }
    
 catch (Exception e) {
            System.err.println("DATABASE QUERY ERROR: " + e.toString());
        }   
    return booked;
}

 public ArrayList<RealEstate> buyRE(int id){
     ArrayList<RealEstate> bought = new ArrayList();
    try{
 Statement stmt = con.createStatement();
 ResultSet rs = stmt.executeQuery("select * from real-estate where id='" + id + "' ");
 while(rs.next()){
     bought.add(new RealEstate(rs.getInt("id"),rs.getString("city"),rs.getString("type"),rs.getString("street"),rs.getString("country"),rs.getInt("totalspace"),rs.getString("postalcode"),rs.getInt("noocupants"),rs.getInt("price")));
     
 }
 rs = stmt.executeQuery("delete * from real-estate where id='" + id + "' ");
    }
    
 catch (Exception e) {
            System.err.println("DATABASE QUERY ERROR: " + e.toString());
        }   
    return bought;
}

public void addtoWishlist(WishList x){
    try{
Statement stmt = con.createStatement();
stmt.executeUpdate(" insert into wishlist values('"+x.getClientID()+"',"+ x.getRealEstateID() +")" );
    }
    catch (Exception e) {
            System.err.println("DATABASE INSERTION ERROR: " + e.toString());
        }
}

public void deletefromwishlist(int id){
try {
            Statement stmt = con.createStatement();
            stmt.executeUpdate("delete from wishlist where id = '" + id + "'");
            System.out.println("WishList it deleted");
        } catch (Exception e) {
            System.err.println("DATABASE DELETION ERROR: " + e.toString());
        }
}
    
    
    
    }
            

