/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rentingsystem;

/**
 *
 * @author user
 */
public class Admin extends User{
    Admin admininstence;
    String username;
    String password;
    float salary;
    String email;

    public Admin( String name, String phone_Number, String email, String password, String address) {
        super(name, phone_Number, address);
          this.admininstence = this;
        this.username = username;
        this.password = password;
        this.salary = salary;
        this.email=email;
    }
public Admin(){
super();
}
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Admin getAdmininstence() {
        return admininstence;
    }

    public void setAdmininstence(Admin admininstence) {
        this.admininstence = admininstence;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public float getSalary() {
        return salary;
    }

    public void setSalary(float salary) {
        this.salary = salary;
    }

    


    

  
    
            
}
