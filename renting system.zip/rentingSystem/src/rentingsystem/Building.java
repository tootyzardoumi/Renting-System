/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rentingsystem;



/**
 *
 * @author salwa saleh
 */
public class Building extends RealEstate{
    public int numberOfFloots;
    public int numberOfRooms;
    public int numberOfBathrooms;

    public Building(int numberOfFloots, int numberOfRooms, int numberOfBathrooms) {
        this.numberOfFloots = numberOfFloots;
        this.numberOfRooms = numberOfRooms;
        this.numberOfBathrooms = numberOfBathrooms;
    }
    public Building(){
    
    }
    public int getNumberOfFloots() {
        return numberOfFloots;
    }

    public void setNumberOfFloots(int numberOfFloots) {
        this.numberOfFloots = numberOfFloots;
    }

    public int getNumberOfRooms() {
        return numberOfRooms;
    }

    public void setNumberOfRooms(int numberOfRooms) {
        this.numberOfRooms = numberOfRooms;
    }

    public int getNumberOfBathrooms() {
        return numberOfBathrooms;
    }

    public void setNumberOfBathrooms(int numberOfBathrooms) {
        this.numberOfBathrooms = numberOfBathrooms;
    }
    
}
