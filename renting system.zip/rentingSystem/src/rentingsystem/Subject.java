/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rentingsystem;

import java.util.ArrayList;

/**
 *
 * @author hp
 */
public class Subject {
    	
   ArrayList<Observer> observers = new ArrayList<Observer>();
   String msg;

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
        notifyAllObservers();
    }
   
   
   public void addObserver(Observer observer){
      observers.add(observer);		
   }
   
   public void removeObserver(Observer observer){
      observers.remove(observer);		
   }

   public void notifyAllObservers(){
      for (Observer observer : observers) {
         observer.update();
      }
   } 	
}

