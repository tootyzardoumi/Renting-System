/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testing;

import java.util.ArrayList;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import org.junit.Test;
import rentingsystem.Client;
import rentingsystem.DB;
import rentingsystem.*;
import rentingsystem.Owner;



/**
 *
 * @author user
 */
public class test {
    static DB db=new DB();
      @Test
    public void testOwnerpassword() {
   
        Owner o = new Owner("villa", "mariam@yahoo.com", 1, 4, "true", "mariam1234", "mariam16", "mariam", "0123456", "cairo");
      
        String result = o.getPassword();
        
        assertEquals(result, "mariam1234");
    }
     @Test
    public void testClientpasswordANDusername() {
        Client c = new Client( new ArrayList(), "mostafa@gmail.com", 153095, "true", "password123", "mostafanegm", "mostafa","0123456789","madinaty");
        String result = c.getPassword();

 

        assertEquals(result, "password123");
    }
    
        @Test
    public void testAppointments() {
        ArrayList<Appointments> a = db.viewappointment();
        assertNotNull(a);
    }
    
    @Test
    public void testCardnumber()
    {
        
         Creditcard c = new Creditcard( 153095,"0123456789101", "3/25", "557","mostafa");
        String result = c.getCardNumber();

 

        assertEquals(result, "0123456789101");
    }
 
    @Test
    public void testgetREbyID(){
 
       RealEstate r = new RealEstate(1,"cairo","apartment","12","egypt",1000,"9090",6,100);
       int result = r.getId();
       assertEquals(result,1);
       
   }
    @Test
    public void testaddtoWishlist(){

     RealEstate r = new RealEstate(1,"abu dhabi","apartment","18","UAE",14590,"7594",6,100);
     String result = r.getCity();
     assertEquals(result,"abu dhabi");
     
    
    }
}

